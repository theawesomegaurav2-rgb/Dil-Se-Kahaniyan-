require("dotenv").config();
const express = require("express");
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");
const Razorpay = require("razorpay");

const app = express();
const PORT = process.env.PORT || 3000;
const BASE_URL = (process.env.BASE_URL || `http://localhost:${PORT}`).replace(/\/$/, "");
const PRICE = Number(process.env.PRODUCT_PRICE_PAISE || 900);
const DATA_FILE = path.join(__dirname, "data", "paid.json");

if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, JSON.stringify({}), "utf8");

const razorpay = process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET
  ? new Razorpay({ key_id: process.env.RAZORPAY_KEY_ID, key_secret: process.env.RAZORPAY_KEY_SECRET })
  : null;

function readPaid() {
  try { return JSON.parse(fs.readFileSync(DATA_FILE, "utf8")); } catch { return {}; }
}
function writePaid(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), "utf8");
}
function signToken(payload) {
  const body = Buffer.from(JSON.stringify(payload)).toString("base64url");
  const sig = crypto.createHmac("sha256", process.env.RAZORPAY_KEY_SECRET || "dev-secret").update(body).digest("base64url");
  return `${body}.${sig}`;
}
function verifyToken(token) {
  if (!token || !token.includes(".")) return null;
  const [body, sig] = token.split(".");
  const expected = crypto.createHmac("sha256", process.env.RAZORPAY_KEY_SECRET || "dev-secret").update(body).digest("base64url");
  if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return null;
  const payload = JSON.parse(Buffer.from(body, "base64url").toString("utf8"));
  if (!payload.exp || Date.now() > payload.exp) return null;
  return payload;
}

app.use(express.static(path.join(__dirname, "public")));

app.post("/api/create-payment-link", express.json(), async (req, res) => {
  try {
    if (!razorpay) return res.status(500).json({ error: "Razorpay keys are not configured on the server." });
    const reference = `DSK-${Date.now()}-${crypto.randomBytes(3).toString("hex")}`;
    const link = await razorpay.paymentLink.create({
      amount: PRICE,
      currency: "INR",
      description: "Dil Se Kahaniyan – 7 Emotional Stories",
      reference_id: reference,
      accept_partial: false,
      expire_by: Math.floor(Date.now()/1000) + 86400,
      callback_url: `${BASE_URL}/payment/callback`,
      callback_method: "get",
      reminder_enable: false,
      notes: { product: "dil-se-kahaniyan", version: "1" }
    });
    res.json({ url: link.short_url, id: link.id });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Payment link create nahi ho paya." });
  }
});

app.get("/payment/callback", (req, res) => {
  const { razorpay_payment_id, razorpay_payment_link_id, razorpay_payment_link_reference_id,
          razorpay_payment_link_status, razorpay_signature } = req.query;

  if (!razorpay_payment_id || !razorpay_payment_link_id || !razorpay_payment_link_reference_id ||
      !razorpay_payment_link_status || !razorpay_signature) {
    return res.redirect("/failed.html");
  }

  const payload = [
    razorpay_payment_link_id,
    razorpay_payment_link_reference_id,
    razorpay_payment_link_status,
    razorpay_payment_id
  ].join("|");

  const expected = crypto.createHmac("sha256", process.env.RAZORPAY_KEY_SECRET)
    .update(payload).digest("hex");

  const valid = expected.length === razorpay_signature.length &&
    crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(razorpay_signature));

  if (!valid || razorpay_payment_link_status !== "paid") {
    return res.redirect("/failed.html");
  }

  const paid = readPaid();
  paid[razorpay_payment_link_id] = {
    payment_id: razorpay_payment_id,
    reference_id: razorpay_payment_link_reference_id,
    paid_at: Date.now()
  };
  writePaid(paid);

  const token = signToken({
    product: "dil-se-kahaniyan",
    link_id: razorpay_payment_link_id,
    payment_id: razorpay_payment_id,
    exp: Date.now() + 24 * 60 * 60 * 1000
  });

  res.redirect(`/success.html?token=${encodeURIComponent(token)}`);
});

/* Razorpay recommends verifying the webhook against the raw request body. */
app.post("/api/razorpay/webhook", express.raw({ type: "application/json" }), (req, res) => {
  const signature = req.headers["x-razorpay-signature"];
  if (!signature || !process.env.RAZORPAY_WEBHOOK_SECRET) return res.status(400).send("bad request");

  const expected = crypto.createHmac("sha256", process.env.RAZORPAY_WEBHOOK_SECRET)
    .update(req.body).digest("hex");

  if (expected.length !== signature.length ||
      !crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(signature))) {
    return res.status(400).send("invalid signature");
  }

  const event = JSON.parse(req.body.toString("utf8"));
  if (event.event === "payment_link.paid") {
    const entity = event.payload?.payment_link?.entity;
    if (entity?.id) {
      const paid = readPaid();
      paid[entity.id] = {
        payment_id: event.payload?.payment?.entity?.id || null,
        reference_id: entity.reference_id || null,
        paid_at: Date.now()
      };
      writePaid(paid);
    }
  }
  res.json({ received: true });
});

app.get("/api/access", (req, res) => {
  const payload = verifyToken(req.query.token);
  if (!payload || payload.product !== "dil-se-kahaniyan") return res.status(403).json({ error: "Invalid or expired access." });

  const paid = readPaid();
  if (!paid[payload.link_id]) return res.status(403).json({ error: "Payment not verified." });

  const stories = JSON.parse(fs.readFileSync(path.join(__dirname, "data", "stories.json"), "utf8"));
  res.json({
    author: "Gaurav Anand",
    title: "Dil Se Kahaniyan",
    stories: stories.map((s, i) => ({ id: i + 1, title: s.title, subtitle: s.subtitle, text: s.text }))
  });
});

app.get("/api/health", (req, res) => res.json({ ok: true }));

app.listen(PORT, () => console.log(`Dil Se Kahaniyan running on ${BASE_URL}`));
