# Dil Se Kahaniyan — ₹9 automated delivery website

## What is included
- Mobile-first Hindi landing page
- Razorpay Payment Link created automatically for each buyer
- ₹9 fixed price
- Successful-payment callback with Razorpay signature verification
- 24-hour signed delivery access token
- 7 stories delivered on a protected page
- Print/Save as PDF button
- Razorpay `payment_link.paid` webhook endpoint for reconciliation

## Setup
1. Install Node.js 18+.
2. Run `npm install`.
3. Copy `.env.example` to `.env`.
4. Put your Razorpay LIVE Key ID and Key Secret in `.env`.
5. Set `BASE_URL` to your deployed HTTPS domain.
6. Run `npm start`.
7. In Razorpay Dashboard, add webhook:
   `https://YOUR-DOMAIN.com/api/razorpay/webhook`
   with event `payment_link.paid` and the same webhook secret.
8. Open `/` on your domain.

## Important
Your existing dashboard-created link (`plink_TQ6ZrlPJHbAdN4`) can still be shared manually, but for automatic redirect + delivery this project creates a fresh Payment Link through the Razorpay API with `callback_url`. This is intentional: Razorpay documents callback URLs on API-created Payment Links, and recommends webhooks for asynchronous payment tracking.

Do not put `RAZORPAY_KEY_SECRET` in frontend JavaScript or GitHub.
